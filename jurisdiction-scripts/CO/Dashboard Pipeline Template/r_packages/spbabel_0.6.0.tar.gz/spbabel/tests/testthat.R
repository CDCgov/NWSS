library(testthat)
library(spbabel)

test_check("spbabel")
